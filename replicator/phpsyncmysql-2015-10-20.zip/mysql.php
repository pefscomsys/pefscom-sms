<?
mysql_connect("host", "user", "pass");
//echo mysql_error();
mysql_select_db("db");
//echo mysql_error();
?>